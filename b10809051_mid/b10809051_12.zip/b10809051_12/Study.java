
/**
 *
 * @author jenny
 */
public interface Study 
{
    abstract String getMajor();
    abstract void setMajor(String major);
    abstract String getDegree();
    abstract void setDegree(String degree);
}
