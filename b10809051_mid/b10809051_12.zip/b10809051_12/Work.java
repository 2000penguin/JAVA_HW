
/**
 *
 * @author jenny
 */
public abstract interface Work 
{
    public abstract String getDepartment();
    public abstract void setDepartment(String department);
    
    public abstract double getSalary();
    public abstract void setSalary(double salary);
}
